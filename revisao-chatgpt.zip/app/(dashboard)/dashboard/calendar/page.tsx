"use client";

import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { getBookings } from "@/lib/bookings";
import { useState } from "react";

export default function CalenderPage() {

const bookings = getBookings();

const diasLotados = bookings
  .filter((b) => b.status !== "cancelled")
  .map((b) => b.date);
const [dataSelecionada, setDataSelecionada] = useState("");
const [horarioSelecionado, setHorarioSelecionado] = useState("");
  return (
    <div className="rounded-2xl bg-white p-6 shadow">
      <h1 className="text-2xl font-bold mb-6">
        Calendário
      </h1>

      <FullCalendar
  plugins={[dayGridPlugin, interactionPlugin]}
  initialView="dayGridMonth"
  locale="pt-br"
  showNonCurrentDates={false}
  fixedWeekCount={false}

  dayCellDidMount={(info) => {
    const data = info.date.toISOString().split("T")[0];

    if (diasLotados.includes(data)) {
      info.el.style.backgroundColor = "#fee2e2";
      info.el.style.color = "#b91c1c";
      info.el.style.fontWeight = "600";
    }
  }}

  dateClick={(info) => {
    setDataSelecionada(info.dateStr);
  }}
/>
{dataSelecionada && (
  <div className="mt-6 rounded-xl border p-5">

    <h2 className="font-semibold text-lg">
      Horários disponíveis
    </h2>

    {/* horários */}

  </div>
)}
<div className="mt-4 flex flex-wrap items-center gap-6 text-sm text-gray-600">

  <div className="flex items-center gap-2">
    <div className="w-4 h-4 rounded border border-yellow-300 bg-yellow-100"></div>
    <span>Hoje</span>
  </div>

  <div className="flex items-center gap-2">
    <div className="w-4 h-4 rounded border border-gray-300 bg-white"></div>
    <span>Disponível</span>
  </div>

  <div className="flex items-center gap-2">
    <div className="w-4 h-4 rounded border border-red-300 bg-red-100"></div>
    <span>Lotado</span>
  </div>
</div>
</div>
  );
}